#!/bin/bash
echo '[START] Launching Soldier...'
python3 soldier_client.py
