import json
import zlib
import base64
import logging

logger = logging.getLogger(__name__)

def compress_data(data: str) -> str:
    """Compress string data using zlib and base64."""
    return base64.b64encode(zlib.compress(data.encode())).decode()

def decompress_data(data_b64: str) -> str:
    """Decompress base64/zlib string data."""
    return zlib.decompress(base64.b64decode(data_b64)).decode()

def pack_message(msg: dict) -> bytes:
    """Pack message to JSON bytes with optional compression."""
    data = json.dumps(msg)
    if len(data) > 1024:
        compressed = compress_data(data)
        data = json.dumps({'cz': compressed})
    return (data + '\n').encode('utf-8')

def unpack_message(line: str) -> dict:
    """Unpack JSON message handling compression with error resilience."""
    try:
        if not line or not line.strip():
            return {}
        msg = json.loads(line)
        if 'cz' in msg:
            msg = json.loads(decompress_data(msg['cz']))
        return msg
    except Exception as e:
        logger.error(f"Unpack failed: {e} | Data: {line[:100]}...")
        return {}
