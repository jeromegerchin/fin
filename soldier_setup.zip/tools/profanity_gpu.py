"""
Profanity GPU/CPU Worker - Auto-Adaptive Calculator
Automatically detects hardware and adapts to any machine configuration.
"""
import numpy as np
import sys
import re
import os
import argparse
import struct
import multiprocessing
import time
from concurrent.futures import ProcessPoolExecutor, as_completed

# Try importing pyopencl - may not be available on all systems
try:
    import pyopencl as cl
    OPENCL_AVAILABLE = True
except ImportError:
    OPENCL_AVAILABLE = False
    print("[!] PyOpenCL not installed. Using CPU-only mode.")

# Constants
PRECOMP_FILE = "../precomp.cpp"
OPENCL_KERNEL = "../profanity.cl"
MP_WORDS = 8

# ============================================================================
# PROGRESS TRACKING
# ============================================================================
class ProgressTracker:
    def __init__(self, total_range):
        self.total_range = total_range
        self.start_time = time.time()
        self.last_update_time = self.start_time
        self.last_count = 0
        
    def get_stats(self, current_count):
        now = time.time()
        elapsed = now - self.start_time
        period = now - self.last_update_time
        
        if period <= 0:
            return 0, 0, 0
            
        # Speed in keys/s
        total_speed = current_count / elapsed if elapsed > 0 else 0
        
        # Percent
        percent = (current_count / self.total_range) * 100 if self.total_range > 0 else 0
        
        # ETA
        remaining = self.total_range - current_count
        eta = remaining / total_speed if total_speed > 1e-6 else 0
        
        self.last_update_time = now
        self.last_count = current_count
        
        return percent, total_speed, eta

    def format_progress(self, current_count):
        percent, speed, eta = self.get_stats(current_count)
        # Format for parsing by soldier client: PROGRESS|[percent]|[speed]|[eta]
        return f"PROGRESS|{percent:.2f}|{speed:.0f}|{eta:.0f}"


# ============================================================================
# HARDWARE DETECTION & AUTO-CONFIGURATION
# ============================================================================
class HardwareConfig:
    """Auto-detect hardware and configure optimal settings"""
    
    def __init__(self):
        self.gpu_available = False
        self.gpu_name = None
        self.gpu_memory_mb = 0
        self.cpu_cores = multiprocessing.cpu_count()
        self.ram_gb = self._detect_ram()
        self.mode = "cpu"  # cpu, gpu, or hybrid
        self.batch_size = 10000  # Default conservative
        
        # Detect GPU
        if OPENCL_AVAILABLE:
            self._detect_gpu()
        
        # Auto-configure batch size based on available resources
        self._configure_batch_size()
        
    def _detect_ram(self):
        """Detect available RAM in GB"""
        try:
            import psutil
            return psutil.virtual_memory().total / (1024**3)
        except ImportError:
            # Fallback: assume 4GB minimum
            return 4.0
    
    def _detect_gpu(self):
        """Detect OpenCL GPU devices"""
        try:
            platforms = cl.get_platforms()
            for p in platforms:
                devices = p.get_devices(device_type=cl.device_type.GPU)
                if devices:
                    self.gpu_available = True
                    self.gpu_name = devices[0].name
                    self.gpu_memory_mb = devices[0].global_mem_size // (1024*1024)
                    self.mode = "gpu"
                    return
            # Try CPU OpenCL as fallback
            for p in platforms:
                devices = p.get_devices(device_type=cl.device_type.CPU)
                if devices:
                    self.gpu_name = f"CPU OpenCL: {devices[0].name}"
                    self.mode = "cpu_opencl"
                    return
        except Exception as e:
            print(f"[!] OpenCL detection failed: {e}")
    
    def _configure_batch_size(self):
        """Auto-configure batch size based on hardware"""
        if self.mode == "gpu":
            # GPU: Use large batches based on VRAM
            if self.gpu_memory_mb >= 8000:
                self.batch_size = 10000000  # 10M
            elif self.gpu_memory_mb >= 4000:
                self.batch_size = 5000000   # 5M
            elif self.gpu_memory_mb >= 2000:
                self.batch_size = 1000000   # 1M
            else:
                self.batch_size = 500000    # 500K
        elif self.mode == "cpu_opencl":
            # CPU OpenCL: Medium batches
            self.batch_size = 100000
        else:
            # Pure Python: Small batches, use multiprocessing
            # Adjust based on RAM
            if self.ram_gb >= 16:
                self.batch_size = 50000
            elif self.ram_gb >= 8:
                self.batch_size = 25000
            else:
                self.batch_size = 10000
    
    def get_worker_count(self):
        """Get optimal number of CPU workers"""
        # Leave 1-2 cores free for system
        return max(1, self.cpu_cores - 1)
    
    def print_config(self):
        """Print detected configuration"""
        print("=" * 60)
        print("  HARDWARE AUTO-DETECTION RESULTS")
        print("=" * 60)
        print(f"  CPU Cores:      {self.cpu_cores}")
        print(f"  RAM:            {self.ram_gb:.1f} GB")
        print(f"  GPU Available:  {self.gpu_available}")
        if self.gpu_name:
            print(f"  GPU Device:     {self.gpu_name}")
            print(f"  GPU Memory:     {self.gpu_memory_mb} MB")
        print(f"  Selected Mode:  {self.mode.upper()}")
        print(f"  Batch Size:     {self.batch_size:,}")
        print(f"  CPU Workers:    {self.get_worker_count()}")
        print("=" * 60)


class MT19937_64:
    def __init__(self, seed):
        self.mt = [0] * 312
        self.mti = 313
        self.mt[0] = seed & 0xFFFFFFFFFFFFFFFF
        for i in range(1, 312):
            self.mt[i] = (6364136223846793005 * (self.mt[i-1] ^ (self.mt[i-1] >> 62)) + i) & 0xFFFFFFFFFFFFFFFF
        self.mti = 312

    def extract_number(self):
        if self.mti >= 312:
            for i in range(312):
                x = (self.mt[i] & 0xFFFFFFFF80000000) + (self.mt[(i+1) % 312] & 0x7FFFFFFF) # Wait, this is 32-bit logic!
                # 64-bit logic: Upper 64-r bits?
                # Standard MT19937-64:
                # x = (mt[i] & UM) | (mt[(i+1)] & LM)
                # UM = 0xFFFFFFFF80000000 ?? No, w=64, r=31.
                # UM = Most Significant (w-r) bits.
                # LM = Least Significant r bits.
                pass
        return 0

# Accurate Implementation
class MT64:
    def __init__(self, seed):
        self.mt = [0]*312
        self.index = 312
        self.mt[0] = seed
        for i in range(1, 312):
            self.mt[i] = (6364136223846793005 * (self.mt[i-1] ^ (self.mt[i-1] >> 62)) + i) & 0xffffffffffffffff

    def extract(self):
        if self.index >= 312:
            self.twist()
        y = self.mt[self.index]
        y = y ^ ((y >> 29) & 0x5555555555555555)
        y = y ^ ((y << 17) & 0x71d67fffeda60000)
        y = y ^ ((y << 37) & 0xfff7eee000000000)
        y = y ^ (y >> 43)
        self.index += 1
        return y & 0xffffffffffffffff

    def twist(self):
        for i in range(312):
            # UM: High 33 bits (64-31=33) -> Mask: 0xFFFFFFFF80000000? No.
            # Split point r=31. 
            # High w-r = 33 bits.
            # Low r = 31 bits.
            # UpperMask = ~((1 << 31) - 1) = ~0x7FFFFFFF = 0xFFFFFFFF80000000
            # LowerMask = 0x7FFFFFFF
            x = (self.mt[i] & 0xffffffff80000000) + (self.mt[(i+1) % 312] & 0x7fffffff)
            xA = x >> 1
            if x % 2 != 0:
                xA = xA ^ 0xB5026F5AA96619E9
            self.mt[i] = self.mt[(i + 156) % 312] ^ xA
        self.index = 0

def load_precomp(filename):
    # Check for binary version first
    bin_file = "precomp.bin"
    if os.path.exists(bin_file):
        print(f"[*] Loading precomputed points from {bin_file}...")
        data = np.fromfile(bin_file, dtype=np.uint32)
        if len(data) == 0:
            print("[!] Error: Bloom Filter file is empty.")
            sys.exit(1)
        return data

    print(f"[*] Loading precomputed points from {filename}...")
    if not os.path.exists(filename):
        print(f"[!] {filename} not found.")
        sys.exit(1)
        
    with open(filename, 'r') as f:
        content = f.read()
    
    # Regex to find points: { { 0x..., ... }, { 0x..., ... } }
    # Each mp_number has 8 words.
    # Group capture: ({ ... }, { ... })
    
    # Simple strategy: find all hex strings 0x[0-9a-fA-F]{8}
    # There are 8160 points * 2 coords * 8 words = 130560 words.
    
    hex_values = re.findall(r'0x[0-9a-fA-F]+', content)
    
    # Filter 32-bit hex
    hex_values = [int(h, 16) for h in hex_values if len(h) <= 10] # 0x + 8 chars
    
    # Expect 8160 * 16 words
    expected_words = 8160 * 16
    if len(hex_values) != expected_words:
        # Try finding the array start
        start_marker = "point g_precomp[8160] = {"
        start_idx = content.find(start_marker)
        if start_idx == -1:
            print("[!] Error: Could not find g_precomp start.")
            sys.exit(1)
        
        subset = content[start_idx:]
        hex_values = re.findall(r'0x[0-9a-fA-F]+', subset)
        hex_values = [int(h, 16) for h in hex_values]
        
        # Verify again
        if len(hex_values) < expected_words:
             print(f"[!] Error: Found {len(hex_values)} words, expected {expected_words}.")
             sys.exit(1)
        
        hex_values = hex_values[:expected_words]

    print(f"[*] Parsed {len(hex_values)} words.")
    
    # Structure: array of points. point = { x, y }. mp_number = { d[0]...d[7] }
    # Data structure for OpenCL buffer:
    # struct point { mp_number x; mp_number y; } maps to 16 * uint32.
    
    # Create numpy array of uint32
    data = np.array(hex_values, dtype=np.uint32)
    return data

def load_kernel(filename):
    with open(filename, 'r') as f:
        return f.read()

# ============================================================================
# CPU MODE - Pure Python Fallback (for machines without GPU)
# ============================================================================
P = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F
N = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141
GX = 0x79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798
GY = 0x483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8

def mod_inverse(a, p):
    if a == 0: return 0
    lm, hm = 1, 0
    low, high = a % p, p
    while low > 1:
        ratio = high // low
        nm, new = hm - lm * ratio, high - low * ratio
        hm, lm, high, low = lm, nm, low, new
    return lm % p

def point_add(p1, p2):
    if p1 is None: return p2
    if p2 is None: return p1
    x1, y1 = p1
    x2, y2 = p2
    if x1 == x2:
        if y1 == y2:
            s = (3 * x1 * x1 * mod_inverse(2 * y1, P)) % P
        else:
            return None
    else:
        s = ((y2 - y1) * mod_inverse(x2 - x1, P)) % P
    x3 = (s * s - x1 - x2) % P
    y3 = (s * (x1 - x3) - y1) % P
    return (x3, y3)

def point_mult(k, point):
    result = None
    addend = point
    while k:
        if k & 1:
            result = point_add(result, addend)
        addend = point_add(addend, addend)
        k >>= 1
    return result

def cpu_worker_hash_table(start_idx, count, bf_size):
    """Worker process for hash table generation"""
    indices = []
    G = (GX, GY)
    for i in range(count):
        seed_val = start_idx + i
        rng = MT64(seed_val)
        x = rng.extract()
        y = rng.extract()
        z = rng.extract()
        w = rng.extract()
        privkey = (x | (y << 64) | (z << 128) | (w << 192)) % N
        pubkey = point_mult(privkey, G)
        
        x_lo = pubkey[0] & 0xFFFFFFFF
        x_hi = (pubkey[0] >> 32) & 0xFFFFFFFF
        h64 = x_lo | (x_hi << 32)
        indices.append(h64 % bf_size)
    return indices

def cpu_worker_reverse(start_offset, count, target_point, bf_bytes, bf_size):
    """Worker process for reverse attack"""
    import bitarray
    bf = bitarray.bitarray()
    bf.frombytes(bf_bytes)
    
    G = (GX, GY)
    neg_G = (GX, P - GY)
    
    # Calculate starting point for this worker's range
    offset_point = point_mult(start_offset, G)
    if offset_point is None:
        current = target_point
    else:
        neg_offset_point = (offset_point[0], P - offset_point[1])
        current = point_add(target_point, neg_offset_point)
    
    results = []
    for k in range(count):
        actual_offset = start_offset + k
        x_lo = current[0] & 0xFFFFFFFF
        x_hi = (current[0] >> 32) & 0xFFFFFFFF
        h64 = x_lo | (x_hi << 32)
        idx = h64 % bf_size
        
        if bf[idx]:
            results.append((actual_offset, current[0]))
            
        current = point_add(current, neg_G)
    return results

def run_cpu_mode(args, config):
    """Run attack in pure Python CPU mode with multi-processing"""
    import bitarray
    
    num_workers = config.get_worker_count()
    print(f"[*] CPU MODE: Using {num_workers} parallel workers")
    
    total_range = args.range
    tracker = ProgressTracker(total_range)
    
    if args.mode == "hash_table":
        if not args.output:
            print("[!] Output file required.")
            return
        
        print(f"[*] CPU MODE: Generating Seed Map (BF Size: 4GB)")
        BF_SIZE = 1 << 35
        bf = bitarray.bitarray(BF_SIZE)
        bf.setall(0)
        
        chunk_size = config.batch_size
        
        with ProcessPoolExecutor(max_workers=num_workers) as executor:
            for i in range(0, total_range, chunk_size * num_workers):
                futures = []
                for w in range(num_workers):
                    start = i + w * chunk_size
                    count = min(chunk_size, total_range - start)
                    if count > 0:
                        futures.append(executor.submit(cpu_worker_hash_table, start, count, BF_SIZE))
                
                for future in as_completed(futures):
                    for idx in future.result():
                        bf[idx] = 1
                
                # Output progress
                print(tracker.format_progress(min(i + chunk_size * num_workers, total_range)), flush=True)

        print(f"[*] Saving Bloom Filter to {args.output}...")
        with open(args.output, 'wb') as f:
            bf.tofile(f)
        print("[+] CPU mode hash_table complete.")
        
    elif args.mode == "reverse":
        if not args.target or not args.table:
            print("[!] Target and table required.")
            return
        
        # Load Bloom Filter
        print(f"[*] Loading Bloom Filter from {args.table}...")
        bf = bitarray.bitarray()
        with open(args.table, 'rb') as f:
            bf.fromfile(f)
        bf_bytes = bf.tobytes() # Share bytes for workers
        bf_size = len(bf)
        
        # Parse target
        t_hex = args.target.replace("0x", "")
        tx = int(t_hex[:64], 16)
        ty = int(t_hex[64:], 16)
        target_point = (tx, ty)
        
        chunk_size = config.batch_size
        
        print(f"[*] Starting Reverse Attack (Range: {total_range:,})...")
        
        with ProcessPoolExecutor(max_workers=num_workers) as executor:
            for i in range(0, total_range, chunk_size * num_workers):
                futures = []
                for w in range(num_workers):
                    start = args.offset + i + w * chunk_size
                    count = min(chunk_size, total_range - (i + w * chunk_size))
                    if count > 0:
                        futures.append(executor.submit(cpu_worker_reverse, start, count, target_point, bf_bytes, bf_size))
                
                for future in as_completed(futures):
                    for offset, x_val in future.result():
                        print(f"\n[+] FOUND CANDIDATE!")
                        print(f"    Offset: {offset}")
                        print(f"    X: {hex(x_val)}")
                        with open("FOUND_KEY.txt", "a") as log:
                            log.write(f"Offset: {offset}, X: {hex(x_val)}\n")
                
                # Output progress
                print(tracker.format_progress(min(i + chunk_size * num_workers, total_range)), flush=True)

        print("[+] CPU mode reverse complete.")

def get_devices():
    try:
        platforms = cl.get_platforms()
        devices = []
        for p in platforms:
            devices.extend(p.get_devices(device_type=cl.device_type.GPU))
        if not devices:
            for p in platforms:
                devices.extend(p.get_devices(device_type=cl.device_type.CPU))
        return devices
    except:
        return []


def main():
    # Limit CPU cores to prevent host freezing
    max_cores = max(1, multiprocessing.cpu_count() - 1)
    
    # Detect hardware first
    config = HardwareConfig()
    config.print_config()
    # Use better entropy for MT seeding across multiple parallel instances
    import os
    import time
    seed_val = int.from_bytes(os.urandom(8), 'big') ^ time.time_ns()
    np.random.seed(seed_val & 0xFFFFFFFF)
    
    parser = argparse.ArgumentParser(description="Profanity GPU Worker")
    parser.add_argument("--mode", choices=["hash_table", "reverse"], required=True)
    parser.add_argument("--output", help="Output file for hash table")
    parser.add_argument("--target", help="Target PubKey (hex, 64 bytes X+Y)")
    parser.add_argument("--offset", type=int, default=0, help="Start offset for reverse")
    parser.add_argument("--range", type=int, default=1000000, help="Range/Steps")
    parser.add_argument("--table", help="Input hash table file")
    parser.add_argument("--cpu", action="store_true", help="Force CPU mode (no GPU)")
    parser.add_argument("--batch", type=int, help="Override batch size")
    
    args = parser.parse_args()
    
    # Apply manual overrides
    if args.batch:
        config.batch_size = args.batch
    if args.cpu:
        config.mode = "cpu"
    
    # Setup execution environment
    ctx = None
    queue = None
    prg = None
    precomp_buf = None
    
    if config.mode in ("gpu", "cpu_opencl"):
        try:
            platforms = cl.get_platforms()
            # If we are in gpu mode, find the GPU device
            device = None
            for p in platforms:
                devs = p.get_devices(device_type=cl.device_type.GPU if config.mode == "gpu" else cl.device_type.CPU)
                if devs:
                    device = devs[0]
                    break
            
            if device:
                ctx = cl.Context([device])
                queue = cl.CommandQueue(ctx)
                
                # Load precomp data
                precomp_data = load_precomp(PRECOMP_FILE)
                mf = cl.mem_flags
                precomp_buf = cl.Buffer(ctx, mf.READ_ONLY | mf.COPY_HOST_PTR, hostbuf=precomp_data)
                
                # Build kernel
                kernel_src = load_kernel(OPENCL_KERNEL)
                prg = cl.Program(ctx, kernel_src).build(options=["-I", "."])
            else:
                print("[!] Requested OpenCL device not found. Falling back to pure Python CPU mode.")
                config.mode = "cpu"
        except Exception as e:
            print(f"[!] OpenCL initialization failed: {e}")
            print("[!] Falling back to pure Python CPU mode.")
            config.mode = "cpu"
    
    if config.mode == "cpu":
        print("[*] Running in pure Python CPU mode (Auto-Adaptive)")
        run_cpu_mode(args, config)
        return
    
    # GPU / OpenCL Mode
    print(f"[*] Starting {args.mode} on {config.gpu_name} (Batch: {config.batch_size:,})")
    
    # ... rest of GPU logic ...
    
    
    if args.mode == "hash_table":
        if not args.output:
            print("[!] Output file required.")
            return
            
        print(f"[*] Generating Seed Map (Bloom Filter). Max Seeds: {2**32}")
        import bitarray
        
        # Bloom Filter settings
        # Size: 4GB (32 billion bits).
        # Items: 4 billion.
        # Bits per item: 8.
        # Hashes: Use parts of the 96-bit public hash.
        BF_SIZE = 1 << 35 # 34G bits = 4GB.
        bf = bitarray.bitarray(BF_SIZE)
        bf.setall(0)
        
        BATCH_SIZE = 1000000 # 1M seeds per batch
        TOTAL_SEEDS = 1 << 32 # 4294967296
        
        # OpenCL Buffers
        mf = cl.mem_flags
        
        # publicAddress buffer: 3 ulongs per seed (actually 3 uints per seed in kernel?)
        # Kernel: __global uint * publicAddress
        # Size: BATCH_SIZE * 3 * 4 bytes
        res_np = np.zeros((BATCH_SIZE * 3), dtype=np.uint32)
        res_buf = cl.Buffer(ctx, mf.WRITE_ONLY, res_np.nbytes)
        
        # Initial Seeds
        # Kernel takes __global ulong4 * seed
        # BUT profanity_init_hash_table uses seed.w for the round?
        # seed_.x, y, z are constant (usually 0 for simple iteration?)
        # Let's check kernel:
        # seed_.x, y, z are used for 8*255*0/1/2.
        # seed_.w is used for 8*255*3.
        # Profanity uses the seed to index 'precomp'.
        # For a standard 64-bit random seed, we mapping it to OpenCL expansion.
        # If we iterate 0..2^32, we just set seed.w = index?
        # Actually, if the Private Key is 256-bit, we are searching only a SUBSET.
        # The user said "seed/private keys... 4 billion possible seeds".
        # This implies the private key is generated from a 32-bit seed expanded.
        # The kernel `profanity_init_seed` does exactly this expansion.
        
        # So we iterate 'w' from 0 to 2^32. 'x,y,z' = 0.
        tracker = ProgressTracker(TOTAL_SEEDS)
        print(f"[*] Starting Seed Map Generation...")
        
        seeds_np = np.zeros((BATCH_SIZE * 4), dtype=np.uint64) # ulong4
        seeds_buf = cl.Buffer(ctx, mf.READ_ONLY, seeds_np.nbytes)
        
        # Compile kernel
        knl = prg.profanity_init_hash_table
        
        print("[*] Starting generation...")
        for i in range(0, TOTAL_SEEDS, BATCH_SIZE):
            current_batch = min(BATCH_SIZE, TOTAL_SEEDS - i)
            
            # Prepare seeds
            # We construct the array on host. 
            # Vectorization is tricky in numpy for struct arrays but linear array works.
            # seeds_np[3::4] = range(i, i + current_batch) -- no, numpy strides.
            # x,y,z are 0.
            
            # Prepare seeds
            # Generate 1M seeds using MT19937-64
            # We must init MT for each seed 'i + k'.
            # Optimized: Just python loop.
            
            raw_seeds = []
            for k in range(current_batch):
                seed_val = i + k
                rng = MT64(seed_val)
                # Profanity uses seed.x, y, z, w
                # x = rng(), y = rng(), z = rng(), w = rng()
                # Assuming simple order.
                s_x = rng.extract()
                s_y = rng.extract()
                s_z = rng.extract()
                s_w = rng.extract()
                raw_seeds.extend([s_x, s_y, s_z, s_w])
            
            seeds_np = np.array(raw_seeds, dtype=np.uint64)
            # seeds_np is flat 4 * batch
            
            # Copy to GPU
            cl.enqueue_copy(queue, seeds_buf, seeds_np).wait()
            
            # Run Kernel
            # Global size = current_batch
            knl(queue, (current_batch,), None, precomp_buf, seeds_buf, None, res_buf)
            
            # Read Result
            cl.enqueue_copy(queue, res_np, res_buf).wait()
            
            # Update Bloom Filter
            # res_np contains [h0_0, h0_1, h0_2, h1_0...]
            # We interpret these min 96 bits as hash indices.
            # Hash 1: res[0] % BF_SIZE
            # Hash 2: res[1] % BF_SIZE
            # Hash 3: res[2] % BF_SIZE
            # This mimics 3 hash functions.
            
            # Optimization: Use numpy to calc indices
            # Reshape to (Batch, 3)
            hashes = res_np.reshape((current_batch, 3))
            
            # Compute modulo BF_SIZE
            # Since BF_SIZE is power of 2, we can mask.
            # But the values are 32-bit. BF_SIZE is 35-bit.
            # We need to combine them to get effective spreading?
            # Actually, `publicAddress` is the X coordinate.
            # It's NOT random distribution. It's coordinates on a curve.
            # We should HASH it first?
            # Profanity just takes X.
            # If we map X directly to BF indices, clusterng might occur.
            # Better to Mix: idx = (x[0] ^ (x[1]<<5)) % BF_SIZE
            
            # For speed, I will enable simple mapping first.
            # The 'bitarray' lib unfortunately doesn't support bulk set from numpy index array efficiently without looping?
            # Actually, it does support setting from iterable.
            
            # Let's simple-loop or verify bitarray API.
            # Assuming we save the RAW table first? No space.
            # I must optimize this host code.
            
            # Construct indices buffer
            # idx1 = hashes[:, 0] # 32-bit
            # BF needs 35-bit index.
            # Let's map h[0] -> bit.
            # But h[0] is only 32 bit range. We waste 7/8 of the BF.
            # We should combine h[0] and h[1].
            # idx = (h0 | (h1 << 32)) % BF_SIZE
            
            h64 = hashes[:, 0].astype(np.uint64) | (hashes[:, 1].astype(np.uint64) << 32)
            indices = h64 % BF_SIZE
            
            # Bulk set?
            # bitarray has no bulk set from list of ints?
            # iterate: for x in indices: bf[x] = 1
            # fast enough in python for 1M? 1M loops takes ~0.1s.
            
            for idx in indices:
                bf[idx] = 1
                
            if i % 1000000 == 0:
                print(tracker.format_progress(i), flush=True)
        
        print("[*] Saving Bloom Filter...")
        with open(args.output, 'wb') as f:
            bf.tofile(f)
        print("[+] Done.")

    elif args.mode == "reverse":
        if not args.target:
            print("[!] Target required.")
            return
        if not args.table:
            print("[!] Hash table (result of hash_table mode) required.")
            return
            
        print("[*] Loading Bloom Filter...")
        import bitarray
        bf = bitarray.bitarray()
        with open(args.table, 'rb') as f:
            bf.fromfile(f)
        BF_SIZE = len(bf)
        print(f"[*] Loaded BF size: {BF_SIZE} bits.")
        
        # Parse Target (Hex 64 bytes X+Y) -> Point
        # e.g. 6a68... (X) ... (Y)
        t_hex = args.target.replace("0x", "")
        if len(t_hex) != 128:
            print("[!] Invalid target length (need 128 hex chars for X+Y).")
            # If user provided 0xAddress, we can't do this.
            # Profanity reverse needs PubKey.
            # User provided: 0x0babe... and recovered PubKeys.
            # Assuming input is the PubKey hex.
            if len(t_hex) == 40:
                 print("[!] Error: You provided an Address. Need Public Key.")
                 return
            return

        tx_int = int(t_hex[:64], 16)
        ty_int = int(t_hex[64:], 16)
        
        # Kernel: profanity_init_reverse
        # Takes 'target' (point struct = 8 words X, 8 words Y)
        # And 'offset' (ulong).
        # Stores result in pDeltaX, pPrevLambda... 
        # Actually, it computes the START state for iteration.
        # Wait, if we want to CHECK `P - kG`, we need the X coordinate of `P - kG`.
        # `profanity_init_reverse` calculates `p = target - s` (where s is offset point).
        # Then it does `pDeltaX[id] = p.x`.
        # So yes, it computes the X coordinate of the shifted point!
        # Perfect.
        
        # struct point mapping
        # x: 8 words. y: 8 words.
        # words are uint32.
        
        def to_mp_number(n):
            # array of 8 uint32, Little Endian?
            # Constants in .cl are little endian: {0xfffffc2f, 0xfffffffe...} = MOD.
            # MOD is 0xfffffffffffffffffffffffffffffffffffffffffffffffffffffffefffffc2f
            # So index 0 is LSB.
            arr = []
            for _ in range(8):
                arr.append(n & 0xFFFFFFFF)
                n >>= 32
            return arr

        target_struct = np.array(to_mp_number(tx_int) + to_mp_number(ty_int), dtype=np.uint32)
        
        # Buffer for DeltaX (Result X)
        # Global size?
        # We process 'range' offsets.
        # Each kernel call processes 'global_size' items.
        
        BATCH_SIZE = 1000000
        total_steps = args.range
        
        # Kernel args: precomp, pDeltaX, pPrevLambda, pResult, target, offset
        # Note: target is struct, passed by value? 
        # Decl: point target.
        # Python wrapper needs to pass struct?
        # Helper: Create struct type or pass buffer?
        # PyOpenCL handles struct if mapped?
        # Easier: Pass as buffer if kernel accepts buffer? No, kernel arg is `point target`.
        # CL struct passing is tricky.
        # ALTERNATIVE: Modify kernel to take `__global uint* target` and load it.
        # But I can't modify kernel easily (user has binary? no I use .cl text).
        # I HAVE .cl text. I CAN MODIFY IT.
        # I will modify `profanity.cl` to accept `__global` pointer for target to avoid alignment/struct issues.
        # OR just define the struct in python.
        
        # Define Struct
        point_dtype = np.dtype([('x', np.uint32, 8), ('y', np.uint32, 8)])
        # Target arg
        t_arr = np.array([(tuple(to_mp_number(tx_int)), tuple(to_mp_number(ty_int)))], dtype=point_dtype)
        # arg[4] = t_arr[0] ?
        
        # Actually, simpler: Use 'set_arg' with the numpy scalar void?
        # PyOpenCL should handle it.
        
        # Buffers
        mf = cl.mem_flags
        pDeltaX = cl.Buffer(ctx, mf.WRITE_ONLY, BATCH_SIZE * 8 * 4) # 8 words * 4 bytes
        pPrevLambda = cl.Buffer(ctx, mf.WRITE_ONLY, BATCH_SIZE * 8 * 4) # Dummy
        pResult = cl.Buffer(ctx, mf.WRITE_ONLY, BATCH_SIZE * 28) 
        
        # Target Buffer (Constant)
        # target_struct is 16 * uint32 (64 bytes)
        target_buf = cl.Buffer(ctx, mf.READ_ONLY | mf.COPY_HOST_PTR, hostbuf=target_struct)
        
        knl = prg.profanity_init_reverse
        
        print(f"[*] Starting Reverse Search. Range: {args.offset} to {args.offset + total_steps}")
        
        found = False
        
        tracker = ProgressTracker(total_steps)
        for i in range(args.offset, args.offset + total_steps, BATCH_SIZE):
            current_batch = min(BATCH_SIZE, args.offset + total_steps - i)
            print(tracker.format_progress(i - args.offset + current_batch), flush=True)
            
            # Run Kernel
            knl(queue, (current_batch,), None, precomp_buf, pDeltaX, pPrevLambda, pResult, target_buf, np.uint64(i))
            
            # Read pDeltaX
            delta_x_np = np.zeros(current_batch * 8, dtype=np.uint32)
            cl.enqueue_copy(queue, delta_x_np, pDeltaX).wait()
            
            # Check against BF
            # reshape (Batch, 8)
            rows = delta_x_np.reshape((current_batch, 8))
            
            # Calculate Hash Indices
            # h0 | (h1 << 32)
            h64 = rows[:, 0].astype(np.uint64) | (rows[:, 1].astype(np.uint64) << 32)
            indices = h64 % BF_SIZE
            
            # Check BF
            # optimize check?
            # for j in range(current_batch): if bf[indices[j]]: verify...
            
            # Vectorized check:
            # We iterate.
            for j, idx in enumerate(indices):
                if bf[idx]:
                    # Possible Match!
                    # Recovered Seed = ?
                    # The Map only stores "Existence".
                    # If it exists, it means (Target - (i+j)*G).x matches a Seed X.
                    # We don't know WHICH seed.
                    # BUT if we know it exists, use the "Forward" table?
                    # The user said "Seed Map of 4 billion possible seeds".
                    # If I use a Bloom Filter, I lose the VALUE of the seed.
                    # I only know "One exists".
                    # This confirms the Private Key is in the set.
                    # To find WHICH seed, I must perform a quick search on the Seed set?
                    # Since I know `P'` matches *some* seed X.
                    # And I know `P'` (I have `rows[j]`).
                    # I can search the `seed_map` if it was a Hash Table.
                    # But I made a Bloom Filter.
                    # If limited to 4B seeds, I can just brute-force the 4B seeds on CPU to find the X?
                    # Or run GPU "Find" kernel?
                    # Actually, if BF matches, it is VERY likely the correct one.
                    # We can print the CANDIDATE OFFSET (i+j).
                    # The "Seed" is unknown, but `Target - Offset` is a "Valid Seed Point".
                    # Wait, the logic is: `Target - kG = S`. `S` must be in the `Seeds` list.
                    # If confirmed, `k` is the missing link? No, `S` corresponds to `seed_value`.
                    # `Priv = seed_value + k` ??
                    # `S = seed_value * G`.
                    # `Target = Priv * G = (seed_value + k) * G = S + kG`. Correct.
                    # So `Priv = seed_value + offset`.
                    # We need `seed_value`.
                    # Since we used a Bloom Filter, we don't have `seed_value`.
                    # However, since `S` is valid, we can find `seed_value` by searching the 4B space for `S`.
                    # That is a generic "Lookup".
                    # Since 4B is small, we can re-run the Generator looking for `S.x`.
                    # Optimized: Print "Candidate Point X: ... Offset: ...".
                    # Then "Refine" step: Find Seed for X.
                    
                    print(f"\n[+] FOUND CANDIDATE!")
                    print(f"Offset (k): {i+j}")
                    print(f"Point X: {rows[j]}")
                    print(f"Index in BF: {idx}")
                    print(f"ACTION: Search for seed producing this X.")
                    found = True
                    # Log to file
                    with open("FOUND_KEY.txt", "a") as log:
                        log.write(f"Offset: {i+j}, X: {rows[j]}\n")
            
            # Progress is printed above via tracker.format_progress


if __name__ == "__main__":
    main()
