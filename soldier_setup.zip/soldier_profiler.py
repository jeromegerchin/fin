"""
SOLDIER HARDWARE PROFILER
Detects full system capabilities for mission matching.
"""
import os
import platform
import subprocess
import json
from dataclasses import dataclass, asdict
from typing import List, Optional

# ============================================================================
# DATA CLASSES
# ============================================================================
@dataclass
class CPUInfo:
    model: str = "Unknown"
    cores: int = 0
    threads: int = 0
    frequency_ghz: float = 0.0
    architecture: str = ""

@dataclass
class RAMInfo:
    total_gb: float = 0.0
    available_gb: float = 0.0
    type: str = "Unknown"

@dataclass
class GPUInfo:
    model: str = "Unknown"
    vram_gb: float = 0.0
    cuda_cores: int = 0
    opencl_version: str = ""
    driver_version: str = ""

@dataclass
class DiskInfo:
    total_gb: float = 0.0
    available_gb: float = 0.0
    type: str = "Unknown"  # SSD or HDD

@dataclass
class OSInfo:
    name: str = ""
    version: str = ""
    architecture: str = ""

@dataclass
class HardwareProfile:
    cpu: CPUInfo
    ram: RAMInfo
    gpus: List[GPUInfo]
    disk: DiskInfo
    os: OSInfo
    hostname: str = ""
    
    def to_dict(self) -> dict:
        return {
            'cpu': asdict(self.cpu),
            'ram': asdict(self.ram),
            'gpus': [asdict(g) for g in self.gpus],
            'disk': asdict(self.disk),
            'os': asdict(self.os),
            'hostname': self.hostname
        }
    
    def has_gpu(self) -> bool:
        return len(self.gpus) > 0 and self.gpus[0].model != "None"
    
    def has_opencl(self) -> bool:
        return any(g.opencl_version for g in self.gpus)
    
    def total_vram_gb(self) -> float:
        return sum(g.vram_gb for g in self.gpus)

# ============================================================================
# DETECTION FUNCTIONS
# ============================================================================
def detect_cpu() -> CPUInfo:
    """Detect CPU information."""
    cpu = CPUInfo()
    cpu.cores = os.cpu_count() or 1
    cpu.threads = cpu.cores
    cpu.architecture = platform.machine()
    
    try:
        if platform.system() == "Windows":
            # Windows: Use PowerShell (more reliable than WMIC)
            ps_cmd = "Get-WmiObject Win32_Processor | Select-Object -First 1 Name, MaxClockSpeed | ConvertTo-Json"
            result = subprocess.run(
                ["powershell", "-Command", ps_cmd],
                capture_output=True, text=True, timeout=10
            )
            if result.returncode == 0:
                import json
                data = json.loads(result.stdout.strip())
                cpu.model = data.get('Name', 'Unknown')
                freq = data.get('MaxClockSpeed', 0)
                cpu.frequency_ghz = round(freq / 1000.0, 2) if freq else 0
        else:
            # Linux: Read /proc/cpuinfo
            with open('/proc/cpuinfo', 'r') as f:
                for line in f:
                    if 'model name' in line:
                        cpu.model = line.split(':')[1].strip()
                    if 'cpu MHz' in line:
                        cpu.frequency_ghz = round(float(line.split(':')[1].strip()) / 1000.0, 2)
    except Exception:
        pass
    
    return cpu

def detect_ram() -> RAMInfo:
    """Detect RAM information."""
    ram = RAMInfo()
    
    try:
        # Try psutil first
        import psutil
        mem = psutil.virtual_memory()
        ram.total_gb = round(mem.total / (1024**3), 2)
        ram.available_gb = round(mem.available / (1024**3), 2)
    except ImportError:
        # Fallback: platform-specific
        try:
            if platform.system() == "Windows":
                result = subprocess.run(
                    ["wmic", "memorychip", "get", "capacity", "/format:csv"],
                    capture_output=True, text=True, timeout=5
                )
                total = 0
                for line in result.stdout.strip().split('\n'):
                    parts = line.split(',')
                    if len(parts) >= 2 and parts[-1].isdigit():
                        total += int(parts[-1])
                ram.total_gb = round(total / (1024**3), 2)
            else:
                with open('/proc/meminfo', 'r') as f:
                    for line in f:
                        if 'MemTotal' in line:
                            ram.total_gb = round(int(line.split()[1]) / (1024**2), 2)
                        if 'MemAvailable' in line:
                            ram.available_gb = round(int(line.split()[1]) / (1024**2), 2)
        except Exception:
            pass
    
    return ram

def detect_gpus() -> List[GPUInfo]:
    """Detect GPU information."""
    gpus = []
    
    # Try NVIDIA first (pynvml)
    try:
        import pynvml
        pynvml.nvmlInit()
        count = pynvml.nvmlDeviceGetCount()
        for i in range(count):
            handle = pynvml.nvmlDeviceGetHandleByIndex(i)
            gpu = GPUInfo()
            gpu.model = pynvml.nvmlDeviceGetName(handle)
            if isinstance(gpu.model, bytes):
                gpu.model = gpu.model.decode('utf-8')
            mem = pynvml.nvmlDeviceGetMemoryInfo(handle)
            gpu.vram_gb = round(mem.total / (1024**3), 2)
            gpu.driver_version = pynvml.nvmlSystemGetDriverVersion()
            if isinstance(gpu.driver_version, bytes):
                gpu.driver_version = gpu.driver_version.decode('utf-8')
            gpus.append(gpu)
        pynvml.nvmlShutdown()
    except Exception:
        pass
    
    # Try OpenCL
    if not gpus:
        try:
            import pyopencl as cl
            platforms = cl.get_platforms()
            for p in platforms:
                for d in p.get_devices(device_type=cl.device_type.GPU):
                    gpu = GPUInfo()
                    gpu.model = d.name
                    gpu.vram_gb = round(d.global_mem_size / (1024**3), 2)
                    gpu.opencl_version = d.version
                    gpus.append(gpu)
        except Exception:
            pass
    
    # Fallback: Windows wmic
    if not gpus and platform.system() == "Windows":
        try:
            result = subprocess.run(
                ["wmic", "path", "win32_VideoController", "get", "name,adapterram", "/format:csv"],
                capture_output=True, text=True, timeout=5
            )
            for line in result.stdout.strip().split('\n'):
                parts = line.split(',')
                if len(parts) >= 3 and parts[1]:
                    gpu = GPUInfo()
                    gpu.vram_gb = round(int(parts[1]) / (1024**3), 2) if parts[1].isdigit() else 0
                    gpu.model = parts[2]
                    gpus.append(gpu)
        except Exception:
            pass
    
    if not gpus:
        gpus.append(GPUInfo(model="None", vram_gb=0))
    
    return gpus

def detect_disk() -> DiskInfo:
    """Detect primary disk information."""
    disk = DiskInfo()
    
    try:
        import shutil
        usage = shutil.disk_usage('/')
        disk.total_gb = round(usage.total / (1024**3), 2)
        disk.available_gb = round(usage.free / (1024**3), 2)
    except Exception:
        try:
            if platform.system() == "Windows":
                usage = os.popen('wmic logicaldisk get size,freespace /format:csv').read()
                for line in usage.strip().split('\n'):
                    parts = line.split(',')
                    if len(parts) >= 3 and parts[1].isdigit():
                        disk.available_gb = round(int(parts[1]) / (1024**3), 2)
                        disk.total_gb = round(int(parts[2]) / (1024**3), 2)
                        break
        except Exception:
            pass
    
    return disk

def detect_os() -> OSInfo:
    """Detect OS information."""
    return OSInfo(
        name=platform.system(),
        version=platform.version(),
        architecture=platform.machine()
    )

def get_hardware_profile() -> HardwareProfile:
    """Get complete hardware profile."""
    return HardwareProfile(
        cpu=detect_cpu(),
        ram=detect_ram(),
        gpus=detect_gpus(),
        disk=detect_disk(),
        os=detect_os(),
        hostname=platform.node()
    )

# ============================================================================
# MAIN
# ============================================================================
if __name__ == "__main__":
    print("Detecting hardware...")
    profile = get_hardware_profile()
    
    print("\n" + "="*50)
    print("  HARDWARE PROFILE")
    print("="*50)
    print(f"\nHostname: {profile.hostname}")
    print(f"\nCPU: {profile.cpu.model}")
    print(f"  Cores: {profile.cpu.cores}, Threads: {profile.cpu.threads}")
    print(f"  Frequency: {profile.cpu.frequency_ghz} GHz")
    print(f"\nRAM: {profile.ram.total_gb} GB total, {profile.ram.available_gb} GB available")
    print(f"\nGPUs:")
    for i, gpu in enumerate(profile.gpus):
        print(f"  [{i}] {gpu.model} - {gpu.vram_gb} GB VRAM")
        if gpu.opencl_version:
            print(f"      OpenCL: {gpu.opencl_version}")
    print(f"\nDisk: {profile.disk.available_gb} GB free / {profile.disk.total_gb} GB total")
    print(f"\nOS: {profile.os.name} {profile.os.version}")
    
    print("\n" + "-"*50)
    print("JSON Output:")
    print(json.dumps(profile.to_dict(), indent=2))
